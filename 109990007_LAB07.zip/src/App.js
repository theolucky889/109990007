import './App.css';
import Title from './components/title';
import {Sidebar, Menu, MenuItem, SubMenu} from 'react-pro-sidebar';


function App() {
  return (
    <div className="App">
      <Title/>
      <header classNAme="App-header">
  <Sidebar>
    <Menu>
      <SubMenu label="Charts">
        <MenuItem>Pie Charts</MenuItem>
        <MenuItem>Line Charts</MenuItem>
      </SubMenu>
      <MenuItem>Documentation</MenuItem>
      <MenuItem>Calender</MenuItem>
      <MenuItem>Calculator</MenuItem>
      <MenuItem>Schedule</MenuItem>
      <MenuItem>Workflow</MenuItem>
    </Menu>
  </Sidebar>



        <p>
          Hope you enjoy!
        </p>
      </header>
    </div>
  );
}

export default App;

